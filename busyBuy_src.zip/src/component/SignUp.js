import styles from "../styles/SignIn.module.css"
export const SignUp=()=>{
    return(
        <>
        <div className={styles.signInContainer}>
            <h1>Sign Up</h1>
            <div className={styles.field}>
                 <input type="text" placeholder="Name"/>
                <input type="text" placeholder="Email"/>
                <input type="text" placeholder="Enter Password"/>
                <button>Sign Up</button>
            </div>
        </div>
        </>
    )
}