import styles from "../styles/SignIn.module.css"
export const SignIn=()=>{
    return(
        <>
        <div className={styles.signInContainer}>
            <h1>Sign In</h1>
            <div className={styles.field}>
                <input type="text" placeholder="Enter Email"/>
                <input type="text" placeholder="Enter Password"/>
                <button>Sign In</button>
            </div>
            <h3 className={styles.signUp}>signUp</h3>
        </div>
        </>
    )
}