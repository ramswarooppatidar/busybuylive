import styles from "../styles/Home.module.css"
import { items } from "../data/data"
import { useValue } from "../itemContext"
export const Home =()=>{
    const {addToCart} = useValue()
    return(
        <>
        <div className={styles.home}>
            <div className={styles.filter}>
                <h1>Filter</h1>
                <h2>price: 1</h2>
                <input type="range" min="1" max="100000" />
                <div className={styles.checkBoxContainer}>
                    <input type="checkbox" id="myCheckbox" name="myCheckbox" value="isChecked"/>
                    <label for="myCheckbox">Women cloth</label>
                    <br/>
                    <input type="checkbox" id="myCheckbox" name="myCheckbox" value="isChecked"/>
                    <label for="myCheckbox">men cloth</label>
                    <br/>
                    <input type="checkbox" id="myCheckbox" name="myCheckbox" value="isChecked"/>
                    <label for="myCheckbox">Jewelleryes</label>
                    <br/>
                    <input type="checkbox" id="myCheckbox" name="myCheckbox" value="isChecked"/>
                    <label for="myCheckbox">electronics</label>

                </div>
            </div>
            <div className={styles.listContainer}>
                {items.map((item, index)=>{
                    return(
                    <div key={index} className={styles.listItem}>
                        <div className={styles.image}>
                            <img src={item.imageUrl}/>
                        </div>
                        <div className={styles.description}>
                          <p><h3>{item.description}</h3></p>
                          <h2>Price {item.price}/-</h2>
                        </div>
                        <div>
                            <button onClick={()=>{addToCart(item)}}>Add To Cart</button>
                        </div>
                    </div>
                    )
                })}              
            </div>
        </div>
        </>
    )
}