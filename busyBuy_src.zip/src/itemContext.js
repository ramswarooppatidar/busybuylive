import { createContext, useContext, useState } from "react";
import { Cart } from "./component/Cart";
import { MyOrder } from "./component/MyOrder";
const itemContext = createContext();

function useValue(){
    const value = useContext(itemContext);
    return value;
}

function CustomItemContext({children}){
    const [cart, setCart] = useState([])
    const [total, setTotal] = useState(0)
    const [order, setOrder] = useState(false)
    const [myOrder, setMyOrder] = useState([])

    const addToCart=(item)=>{
        console.log("items : ",item)
    const index = cart.findIndex((crt)=>crt.id === item.id)
    if(index === -1){
        setCart([...cart, {...item, qty:1}])
        setTotal(total + item.price)
     }
     //else{
        
    //     cart[index].qty++;
    //     setCart(cart)
    // }
    else {
        // Create a copy of the cart array
        const updatedCart = [...cart];
        // Update the quantity of the existing item in the copied array
        updatedCart[index] = { ...updatedCart[index], qty: updatedCart[index].qty + 1 };
        // Update the state with the new cart array
        setCart(updatedCart);
        setTotal(total + item.price)
    }
    }
    const decreseQty=(item)=>{
        const index = cart.findIndex((crt)=> crt.id === item.id)
        if(cart[index].qty <= 1){
            removeFromCart(item)
            return;
        }
        if(index !== -1){
            const updatedCart = [...cart]
            updatedCart[index] = {...updatedCart[index], qty : updatedCart[index].qty - 1}
            setCart(updatedCart)
            setTotal(total - item.price)
        }
    }

    const removeFromCart1=(item)=>{
        const index = cart.findIndex((crt)=>crt.id === item.id)
        if(total - cart[index].qty*item.price <=0){
            return;
        }
        setTotal(total - cart[index].qty*item.price)
        const updatedCart = cart.filter((crt)=> crt.id !== item.id)
        setCart(updatedCart)

    }
    const removeFromCart = (item) => {
        const index = cart.findIndex((crt) => crt.id === item.id);
        if (index === -1) {
            return; // Item not found in cart
        }
    
        const itemTotalPrice = cart[index].qty * item.price;
    
        // Update the total by subtracting the total price of the item to be removed
        setTotal(total - itemTotalPrice);
    
        // Filter out the item to be removed from the cart
        const updatedCart = cart.filter((crt) => crt.id !== item.id);
        setCart(updatedCart);
    };
    const purchase=()=>{
       // setCart(cart);
    //    event.preventDefault();
       setOrder(true)
       setMyOrder([...cart]) ;
       setCart([])
       setTotal(0)    
    }
    return(
        <itemContext.Provider value={{addToCart,
                                        decreseQty,
                                        cart,
                                        total,
                                        myOrder,
                                        removeFromCart,
                                        purchase}}>
            {children}
            {/* {myOrder && <MyOrder cart={cart} 
                                total={total} 
                                myOrder={myOrder}/>} */}
        </itemContext.Provider>
    )
   
}
export {useValue}
export default CustomItemContext;