export const items =[
    {
        id : 1,
        imageUrl : "https://images.pexels.com/photos/620074/pexels-photo-620074.jpeg?auto=compress&cs=tinysrgb&w=600",
        description : "This is a discription for this products",
        price : 1234
    },
    {
        id : 2,
        imageUrl : "https://images.pexels.com/photos/1454168/pexels-photo-1454168.jpeg?auto=compress&cs=tinysrgb&w=600",
        description : "This is a discription for this products",
        price : 1234
    },
    {
        id : 3,
        imageUrl : "https://images.pexels.com/photos/1454172/pexels-photo-1454172.jpeg?auto=compress&cs=tinysrgb&w=600",
        description : "This is a discription for this products",
        price : 1234
    },
    {
        id : 4,
        imageUrl : "https://images.pexels.com/photos/1374128/pexels-photo-1374128.jpeg?auto=compress&cs=tinysrgb&w=600",
        description : "This is a discription for this products",
        price : 1234
    },
    {
        id : 5,
        imageUrl : "https://rukminim2.flixcart.com/image/750/900/jxtakcw0/jewellery-set/w/t/n/wstpstg0057-disharts-original-imafg68d7snyrvrg.jpeg?q=20&crop=false",
        description : "This is a discription for this products",
        price : 1234
    },
    {
        id : 6,
        imageUrl : "https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcR8W5rjUPxjP2FlnR2KptNOZWCmzvngz1NlonME1BdGSA2w6EUs6UN0n3rouBC2u8FaUVSSxopVLVm9sawdYaWdZ56oZsjp_ecQmFrjrBVhswVvAthJpaGJ",
        description : "This is a discription for this products",
        price : 1234
    },
    {
        id : 7,
        imageUrl : "https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcQTkDV3JrSgOVN6W5ry62_NGS9E5daVP1Z-49j64aISRdpgvjc4z224VmVjnqsl4gK0OExrTXa0QJmwOoIKRKnXHXOG4zgC",
        description : "This is a discription for this products",
        price : 1234
    },
    {
        id : 8,
        imageUrl : "https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcRWIlb0UuYzVF4u0zgbWrRVl5VivDs1rqx0YFlXVW_BYj0DkmMCMbit1tNRFDAj2QTfTvJ_6VKu-Y2OLZXqy0zJ04ChE4jKohAMSXZcgLuH2HcldfdwITA1CQ",
        description : "This is a discription for this products",
        price : 1234
    },
    {
        id : 9,
        imageUrl : "https://gallery.yopriceville.com/downloadfullsize/send/4280",
        description : "This is a discription for this products",
        price : 1234
    },
    {
        id : 10,
        imageUrl : "https://www.online-tech-tips.com/wp-content/uploads/2019/12/electronic-gadgets.jpeg",
        description : "This is a discription for this products",
        price : 1234
    },
    {
        id:11,
        imageUrl : "https://vingsfire.com/wp-content/uploads/2023/09/Rectangle-13-1024x914.png",
        description : "electronic product",
        price : 12345
    },
    {
        id:12,
        imageUrl : "https://www.electronicproducts.com/wp-content/uploads/computer-peripheral-communication-peripherals-electronics.jpg",
        description : "electronic product",
        price : 12345
    },
    {
        id:13,
        imageUrl : "https://www.jovifashion.com/upload/product/cdr1821022_638389342020248127.jpg",
        description : "cloth ",
        price : 12345
    },
    {
        id:14,
        imageUrl : "https://m.media-amazon.com/images/I/81Y6izRK+wL._AC_UF894,1000_QL80_.jpg",
        description : "cloth product",
        price : 12345
    },
    {
        id:15,
        imageUrl : "https://fakestoreapi.com/img/81fPKd-2AYL._AC_SL1500_.jpg",
        description : "electronic product",
        price : 12345
    },
    {
        id:16,
        imageUrl : "https://fakestoreapi.com/img/61U7T1koQqL._AC_SX679_.jpg",
        description : "electronic product",
        price : 12345
    },
    {
        id:17,
        imageUrl : "https://fakestoreapi.com/img/71HblAHs5xL._AC_UY879_-2.jpg",
        description : "electronic product",
        price : 12345
    },
    {
        id:18,
        imageUrl : "https://fakestoreapi.com/img/81QpkIctqPL._AC_SX679_.jpg",
        description : "electronic product",
        price : 12345
    },
    {
        id:19,
        imageUrl : "https://fakestoreapi.com/img/61mtL65D4cL._AC_SX679_.jpg",
        description : "electronic product",
        price : 12345
    },
    {
        id:20,
        imageUrl : "https://fakestoreapi.com/img/71pWzhdJNwL._AC_UL640_QL65_ML3_.jpg",
        description : "electronic product",
        price : 12345
    },
    {
        id:21,
        imageUrl : "https://fakestoreapi.com/img/51eg55uWmdL._AC_UX679_.jpg",
        description : "electronic product",
        price : 12345
    },
    {
        id:22,
        imageUrl : "https://fakestoreapi.com/img/61IBBVJvSDL._AC_SY879_.jpg",
        description : "electronic product",
        price : 12345
    },
    {
        id:23,
        imageUrl : "https://fakestoreapi.com/img/71li-ujtlUL._AC_UX679_.jpg",
        description : "electronic product",
        price : 12345
    },
    {
        id:24,
        imageUrl : "https://fakestoreapi.com/img/71-3HjGNDUL._AC_SY879._SX._UX._SY._UY_.jpg",
        description : "electronic product",
        price : 12345
    },
]